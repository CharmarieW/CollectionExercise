import UIKit

var movies = [Int] ()

movies.append(40)

var horror: [String] = ["The Conjouring", "The Purge", "Unfriended"]

var comedy: [String] = ["50 First Dates", "Grandpa"]

comedy.append("Space Jam")

var action: [String] = ["Extraction", "Sniper", "The Hunt"]

action.append("My Spy")

for item in horror{
    print(item)
}

for item in comedy{
    print(item)
}

for item in action{
    print(item)
}
